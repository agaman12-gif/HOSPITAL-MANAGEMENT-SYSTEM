// Simple client that talks to the API using fetch and stores JWT in localStorage.
// For production use a proper frontend framework and secure token handling.

const apiBase = '/api';

function setAuthResult(msg) {
  document.getElementById('auth-result').innerText = msg;
}

async function register() {
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  const res = await fetch(`${apiBase}/auth/register`, {
    method: 'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({username, password})
  });
  const text = await res.text();
  setAuthResult(text);
}

async function login() {
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  const res = await fetch(`${apiBase}/auth/login`, {
    method: 'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({username, password})
  });
  if (!res.ok) {
    setAuthResult('Login failed');
    return;
  }
  const data = await res.json();
  localStorage.setItem('token', data.token);
  setAuthResult('Logged in');
  document.getElementById('patients').style.display = 'block';
}

function authHeaders() {
  const token = localStorage.getItem('token');
  return token ? {'Content-Type':'application/json', 'Authorization': 'Bearer ' + token} : {'Content-Type':'application/json'};
}

async function listPatients() {
  const res = await fetch(`${apiBase}/patients`, { headers: authHeaders() });
  if (!res.ok) {
    document.getElementById('patients-list').innerText = 'Error: ' + res.status;
    return;
  }
  const patients = await res.json();
  document.getElementById('patients-list').innerText = JSON.stringify(patients, null, 2);
}

async function createPatient() {
  const name = document.getElementById('p-name').value;
  const phone = document.getElementById('p-phone').value;
  const address = document.getElementById('p-address').value;
  const payload = { fullName: name, phone, address };
  const res = await fetch(`${apiBase}/patients`, {
    method: 'POST',
    headers: authHeaders(),
    body: JSON.stringify(payload)
  });
  if (!res.ok) {
    alert('Failed to create patient: ' + res.status);
  } else {
    alert('Patient created');
    listPatients();
  }
}
