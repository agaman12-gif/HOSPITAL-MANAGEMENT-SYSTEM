const apiBase = '/api';
const state = {
  currentView: 'dashboard',
  patients: [],
  appointments: [],
  doctors: [],
  billing: [],
  charts: null
};

function setAuthResult(msg) {
  const el = document.getElementById('auth-result');
  if (el) el.innerText = msg;
}

function showToast(message, type = 'info') {
  const stack = document.getElementById('toast-stack');
  if (!stack) return;
  const toast = document.createElement('div');
  toast.className = 'toast-item';
  toast.innerHTML = `<i class="fas ${type === 'success' ? 'fa-check-circle' : type === 'error' ? 'fa-exclamation-circle' : 'fa-info-circle'} me-2"></i>${message}`;
  stack.appendChild(toast);
  setTimeout(() => toast.remove(), 2200);
}

function attachRippleEffect() {
  document.addEventListener('click', (event) => {
    const button = event.target.closest('.btn-ripple');
    if (!button) return;
    const circle = document.createElement('span');
    const rect = button.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    circle.className = 'ripple';
    circle.style.width = circle.style.height = `${size}px`;
    circle.style.left = `${event.clientX - rect.left - size / 2}px`;
    circle.style.top = `${event.clientY - rect.top - size / 2}px`;
    button.appendChild(circle);
    setTimeout(() => circle.remove(), 600);
  });
}

function setButtonLoading(button, loading) {
  if (!button) return;
  if (loading) {
    button.disabled = true;
    button.innerHTML = '<span class="me-2"><i class="fas fa-spinner fa-spin"></i></span>Working...';
  } else {
    button.disabled = false;
    button.innerHTML = button.dataset.originalText || button.innerHTML;
  }
}

function toggleAuthMode(mode) {
  const loginPanel = document.getElementById('login-form-panel');
  const registerPanel = document.getElementById('register-form-panel');
  const loginToggle = document.getElementById('show-login-btn');
  const registerToggle = document.getElementById('show-register-btn');

  if (mode === 'register') {
    loginPanel?.classList.add('d-none');
    registerPanel?.classList.remove('d-none');
    loginToggle?.classList.remove('active');
    registerToggle?.classList.add('active');
  } else {
    loginPanel?.classList.remove('d-none');
    registerPanel?.classList.add('d-none');
    loginToggle?.classList.add('active');
    registerToggle?.classList.remove('active');
  }
}

function showView(viewName) {
  document.querySelectorAll('.view-section').forEach((section) => {
    section.classList.toggle('d-none', section.id !== `${viewName}-view`);
  });
  document.querySelectorAll('.nav-link[data-view]').forEach((link) => {
    link.classList.toggle('active', link.dataset.view === viewName);
  });
  state.currentView = viewName;
  if (viewName === 'dashboard') {
    renderDashboardCharts();
  }
}

function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('show');
}

function authHeaders() {
  const token = localStorage.getItem('token');
  return token
    ? { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token }
    : { 'Content-Type': 'application/json' };
}

async function register() {
  const username = document.getElementById('register-username')?.value || document.getElementById('username').value;
  const password = document.getElementById('register-password')?.value || document.getElementById('password').value;
  const res = await fetch(`${apiBase}/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  });
  const text = await res.text();
  setAuthResult(text);
  showToast('Registration request submitted', 'success');
}

async function login() {
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  const loginButton = document.querySelector('#login-screen .btn-primary');
  loginButton.dataset.originalText = loginButton.innerHTML;
  setButtonLoading(loginButton, true);

  try {
    const res = await fetch(`${apiBase}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });

    if (!res.ok) {
      setAuthResult('Login failed');
      showToast('Login failed. Please verify your credentials.', 'error');
      return;
    }

    const data = await res.json();
    localStorage.setItem('token', data.token);
    setAuthResult('Welcome back!');
    document.getElementById('login-screen').classList.add('d-none');
    document.getElementById('app-shell').classList.remove('d-none');
    showToast('Welcome back to CityCare dashboard', 'success');
    await loadDashboardData();
    showView('dashboard');
  } finally {
    setButtonLoading(loginButton, false);
  }
}

function logout() {
  localStorage.removeItem('token');
  document.getElementById('app-shell').classList.add('d-none');
  document.getElementById('login-screen').classList.remove('d-none');
  document.getElementById('username').value = '';
  document.getElementById('password').value = '';
  document.getElementById('register-username').value = '';
  document.getElementById('register-password').value = '';
  toggleAuthMode('login');
  setAuthResult('You have been logged out.');
  showToast('Logged out successfully', 'info');
}

async function loadDashboardData() {
  try {
    const [patientsResult, appointmentsResult, doctorsResult, billingResult] = await Promise.allSettled([
      fetch(`${apiBase}/patients`, { headers: authHeaders() }),
      fetch(`${apiBase}/appointments`, { headers: authHeaders() }),
      fetch(`${apiBase}/doctors`, { headers: authHeaders() }),
      fetch(`${apiBase}/billing`, { headers: authHeaders() })
    ]);

    if (patientsResult.status === 'fulfilled' && patientsResult.value.ok) {
      state.patients = await patientsResult.value.json();
    }
    if (appointmentsResult.status === 'fulfilled' && appointmentsResult.value.ok) {
      state.appointments = await appointmentsResult.value.json();
    }
    if (doctorsResult.status === 'fulfilled' && doctorsResult.value.ok) {
      state.doctors = await doctorsResult.value.json();
    }
    if (billingResult.status === 'fulfilled' && billingResult.value.ok) {
      state.billing = await billingResult.value.json();
    }
  } catch (error) {
    console.error(error);
  }

  if (!state.doctors.length) {
    state.doctors = [
      { fullName: 'Dr. Asha Rao', specialty: 'Cardiology', experience: 12, status: 'Available' },
      { fullName: 'Dr. Neeraj Singh', specialty: 'Neurology', experience: 8, status: 'Busy' },
      { fullName: 'Dr. Meera Shah', specialty: 'Pediatrics', experience: 10, status: 'Available' },
      { fullName: 'Dr. Rahul Menon', specialty: 'Orthopedics', experience: 15, status: 'Available' }
    ];
  }

  if (!state.billing.length) {
    state.billing = [
      { invoice: 'INV-1042', patient: 'Naina K', amount: '$420', status: 'Paid', date: '2026-07-29' },
      { invoice: 'INV-1043', patient: 'Sanjay R', amount: '$295', status: 'Pending', date: '2026-07-30' },
      { invoice: 'INV-1044', patient: 'Mina T', amount: '$610', status: 'Paid', date: '2026-07-31' }
    ];
  }

  renderDashboard();
  renderPatientTable();
  renderAppointmentTable();
  renderDoctorCards();
  renderBillingTable();
  renderReportsTable();
  renderDashboardCharts();
}

function renderDashboard() {
  const totalPatients = state.patients.length;
  const totalAppointments = state.appointments.length;
  const emergencyCases = Math.max(3, Math.min(9, totalPatients + 2));
  const availableBeds = 42 - Math.min(20, totalPatients + 3);
  const revenue = state.billing.reduce((sum, item) => sum + Number((item.amount || '$0').replace(/[^\d.]/g, '')), 0);

  document.getElementById('patient-count').textContent = totalPatients;
  document.getElementById('doctor-count').textContent = state.doctors.length;
  document.getElementById('appointment-count').textContent = totalAppointments;
  document.getElementById('bed-count').textContent = availableBeds;
  document.getElementById('emergency-count').textContent = emergencyCases;
  document.getElementById('revenue-count').textContent = `$${Math.round(revenue).toLocaleString()}`;

  const recentActivity = document.getElementById('recent-activity');
  recentActivity.innerHTML = state.appointments.slice(0, 4).map((item) => {
    const patientName = item.patient?.fullName || 'Patient';
    const status = item.status || 'Scheduled';
    return `<li class="list-group-item border-0 px-0"><div class="d-flex justify-content-between"><span>${patientName}</span><span class="badge bg-light text-dark">${status}</span></div></li>`;
  }).join('');
}

async function createPatient() {
  const payload = {
    fullName: document.getElementById('p-name').value,
    phone: document.getElementById('p-phone').value,
    address: document.getElementById('p-address').value,
    gender: document.getElementById('p-gender').value,
    dateOfBirth: document.getElementById('p-dob').value,
    medicalHistory: document.getElementById('p-history').value
  };

  const button = document.querySelector('#patient-form button[type="submit"]');
  button.dataset.originalText = button.innerHTML;
  setButtonLoading(button, true);

  try {
    const res = await fetch(`${apiBase}/patients`, {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify(payload)
    });

    if (!res.ok) {
      showToast('Failed to create patient', 'error');
      return;
    }

    document.getElementById('patient-form').reset();
    showToast('Patient saved successfully', 'success');
    await loadDashboardData();
    showView('patients');
  } finally {
    setButtonLoading(button, false);
  }
}

function renderPatientTable() {
  const tbody = document.getElementById('patients-table-body');
  if (!tbody) return;
  tbody.innerHTML = state.patients.map((patient) => `
    <tr>
      <td>${patient.fullName || 'Unknown'}</td>
      <td>${patient.phone || '-'}</td>
      <td>${patient.gender || '-'}</td>
      <td>${patient.address || '-'}</td>
      <td><span class="badge badge-pill bg-success-subtle text-success">Active</span></td>
      <td>
        <button class="btn btn-sm btn-outline-primary me-2 btn-ripple"><i class="fas fa-edit"></i></button>
        <button class="btn btn-sm btn-outline-danger btn-ripple"><i class="fas fa-trash"></i></button>
      </td>
    </tr>
  `).join('');
}

async function createAppointment() {
  const patientId = Number(document.getElementById('a-patient-id').value);
  const doctorId = Number(document.getElementById('a-doctor-id').value);
  const appointmentTimeRaw = document.getElementById('a-time').value;

  if (!patientId || !doctorId) {
    showToast('Please enter valid patient and doctor IDs.', 'error');
    return;
  }

  const payload = {
    patient: { id: patientId },
    doctor: { id: doctorId },
    appointmentTime: appointmentTimeRaw ? `${appointmentTimeRaw}:00` : null,
    notes: document.getElementById('a-notes').value,
    status: document.getElementById('a-status').value
  };

  const button = document.querySelector('#appointment-form button[type="submit"]');
  button.dataset.originalText = button.innerHTML;
  setButtonLoading(button, true);

  try {
    const res = await fetch(`${apiBase}/appointments`, {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify(payload)
    });

    if (!res.ok) {
      const errorText = await res.text();
      showToast(errorText || 'Failed to book appointment', 'error');
      return;
    }

    document.getElementById('appointment-form').reset();
    showToast('Appointment booked successfully', 'success');
    await loadDashboardData();
    showView('appointments');
  } finally {
    setButtonLoading(button, false);
  }
}

function renderAppointmentTable() {
  const tbody = document.getElementById('appointments-table-body');
  if (!tbody) return;
  tbody.innerHTML = state.appointments.map((item) => `
    <tr>
      <td>${item.patient?.fullName || 'Patient'}</td>
      <td>${item.doctor?.fullName || 'Doctor'}</td>
      <td>${item.appointmentTime || '-'}</td>
      <td><span class="badge badge-pill bg-info-subtle text-info">${item.status || 'Scheduled'}</span></td>
      <td>
        <button class="btn btn-sm btn-outline-primary me-2 btn-ripple"><i class="fas fa-eye"></i></button>
        <button class="btn btn-sm btn-outline-danger btn-ripple"><i class="fas fa-trash"></i></button>
      </td>
    </tr>
  `).join('');
}

function renderDoctorCards() {
  const container = document.getElementById('doctor-grid');
  if (!container) return;
  container.innerHTML = state.doctors.map((doctor) => `
    <div class="col-md-6 col-xl-3">
      <div class="module-card p-4">
        <div class="d-flex align-items-center mb-3">
          <div class="stat-icon me-3"><i class="fas fa-user-md"></i></div>
          <div>
            <h6 class="mb-0">${doctor.fullName || 'Doctor'}</h6>
            <small class="text-muted">${doctor.specialty || 'General'}</small>
          </div>
        </div>
        <p class="text-muted mb-2">Experience: ${doctor.experience || '8'} years</p>
        <span class="badge ${doctor.status === 'Busy' ? 'bg-warning-subtle text-warning' : 'bg-success-subtle text-success'}">${doctor.status || 'Available'}</span>
      </div>
    </div>
  `).join('');
}

function renderBillingTable() {
  const tbody = document.getElementById('billing-table-body');
  if (!tbody) return;
  tbody.innerHTML = state.billing.map((item) => `
    <tr>
      <td>${item.invoice || '-'}</td>
      <td>${item.patient || '-'}</td>
      <td>${item.amount || '-'}</td>
      <td><span class="badge ${item.status === 'Pending' ? 'bg-warning-subtle text-warning' : 'bg-success-subtle text-success'}">${item.status || '-'}</span></td>
      <td>${item.date || '-'}</td>
    </tr>
  `).join('');
}

function renderReportsTable() {
  const tbody = document.getElementById('reports-table-body');
  if (!tbody) return;
  tbody.innerHTML = [
    { report: 'Daily Census', period: 'Today', status: 'Ready', owner: 'Nurse Team' },
    { report: 'Revenue Summary', period: 'This month', status: 'Synced', owner: 'Finance' },
    { report: 'Patient Outcomes', period: 'Quarterly', status: 'Review', owner: 'Clinical Lead' }
  ].map((report) => `
    <tr>
      <td>${report.report}</td>
      <td>${report.period}</td>
      <td><span class="badge bg-info-subtle text-info">${report.status}</span></td>
      <td>${report.owner}</td>
    </tr>
  `).join('');
}

function renderDashboardCharts() {
  if (!window.Chart) return;
  const patientCtx = document.getElementById('patient-stats-chart');
  const appointmentCtx = document.getElementById('appointment-analytics-chart');
  const monthlyCtx = document.getElementById('monthly-report-chart');

  if (state.charts) {
    Object.values(state.charts).forEach((chart) => chart.destroy());
  }
  state.charts = {};

  if (patientCtx) {
    state.charts.patient = new Chart(patientCtx, {
      type: 'bar',
      data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [{
          label: 'Patients',
          data: [45, 52, 60, 58, 72, 84],
          backgroundColor: ['#2168f2', '#4fb3ff', '#2bb673', '#f4b942', '#e85151', '#2168f2'],
          borderRadius: 10
        }]
      },
      options: { responsive: true, plugins: { legend: { display: false } } }
    });
  }

  if (appointmentCtx) {
    state.charts.appointment = new Chart(appointmentCtx, {
      type: 'line',
      data: {
        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
        datasets: [{
          label: 'Appointments',
          data: [18, 24, 20, 27, 31, 22],
          borderColor: '#2168f2',
          backgroundColor: 'rgba(33,104,242,0.12)',
          fill: true,
          tension: 0.35
        }]
      },
      options: { responsive: true, plugins: { legend: { display: false } } }
    });
  }

  if (monthlyCtx) {
    state.charts.monthly = new Chart(monthlyCtx, {
      type: 'doughnut',
      data: {
        labels: ['Admissions', 'Consultations', 'Diagnostics'],
        datasets: [{
          data: [40, 35, 25],
          backgroundColor: ['#2168f2', '#4fb3ff', '#2bb673']
        }]
      },
      options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
    });
  }
}

document.addEventListener('DOMContentLoaded', () => {
  attachRippleEffect();
  toggleAuthMode('login');

  document.querySelectorAll('.nav-link[data-view]').forEach((link) => {
    link.addEventListener('click', (event) => {
      event.preventDefault();
      showView(link.dataset.view);
    });
  });

  document.getElementById('logout-btn')?.addEventListener('click', logout);
  document.getElementById('sidebar-toggle')?.addEventListener('click', toggleSidebar);
  document.getElementById('book-appointment-btn')?.addEventListener('click', () => {
    document.getElementById('appointment-form')?.requestSubmit();
  });

  document.getElementById('patient-form')?.addEventListener('submit', (event) => {
    event.preventDefault();
    createPatient();
  });

  document.getElementById('appointment-form')?.addEventListener('submit', (event) => {
    event.preventDefault();
    createAppointment();
  });

  document.addEventListener('click', (event) => {
    if (event.target.id === 'sidebar' || event.target.closest('.sidebar')) return;
    document.getElementById('sidebar')?.classList.remove('show');
  });
});
